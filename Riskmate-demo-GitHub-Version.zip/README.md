# RiskMate Demo

This is a soft demo preview of the RiskMate landing page. Built to show the vision and branding for the upcoming app.

## Preview

- Landing design with logo
- Tagline: "Your Safety Sorted"
- Placeholder button for demo flow
